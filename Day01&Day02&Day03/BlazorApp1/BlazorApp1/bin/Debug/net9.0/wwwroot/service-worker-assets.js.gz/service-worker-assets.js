self.assetsManifest = {
  "version": "3b5eijd4",
  "assets": [
    {
      "hash": "sha256-6OhRVx3ca1BBU+NMs10Cy77IyTa9gDaX90aYXVc1oAI=",
      "url": "BlazorApp1.styles.css"
    },
    {
      "hash": "sha256-Hggb6t0toMuiTjCWLeZ3acOiAiX6//MRYV8AqeSg1s4=",
      "url": "_framework/BlazorApp1.igxurqx1ng.pdb"
    },
    {
      "hash": "sha256-BKJtKwLvOy0e8XtsLiuK51llQ7bu7G5PDNaLRd5gN0g=",
      "url": "_framework/BlazorApp1.ozw4upkkt6.wasm"
    },
    {
      "hash": "sha256-M+ZhqdAsD2tM9ZVCEvlpGIgptSQ5ffP3i2kQrFRpeaI=",
      "url": "_framework/Microsoft.AspNetCore.Authorization.j0mj4vhukl.wasm"
    },
    {
      "hash": "sha256-PDuUdgnLN/MGbRe8abwuhKoiO3YitNasmf9dVq69Db4=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.gr2x7qa88t.wasm"
    },
    {
      "hash": "sha256-xhg5jMnmR2St2kW/7HTxROvlhwB4uxU3K4An8mS04Xk=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.mh0fj55zay.wasm"
    },
    {
      "hash": "sha256-W8T2NZk43cGtFod2Ssv1YQjVSmhUTu/oS7W4B8DqtCc=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.te1uldh58k.wasm"
    },
    {
      "hash": "sha256-zYEy9TRZ+ZZjqdGAu64nCHIxcZWwaElbjD+Ck3eYA7w=",
      "url": "_framework/Microsoft.AspNetCore.Components.h3xttq5c32.wasm"
    },
    {
      "hash": "sha256-ZJ7lUXAZBzHIaYRsch4ZnX/qTe9d6Kfgcfvfmz/mFZw=",
      "url": "_framework/Microsoft.AspNetCore.Metadata.c0pgrl1c1k.wasm"
    },
    {
      "hash": "sha256-siXjhbF/WGgNdiLsMs7oyA66L5/8uzUgOE9+/YZt57A=",
      "url": "_framework/Microsoft.CSharp.aiisld9zgk.wasm"
    },
    {
      "hash": "sha256-DUthMu8TE0jdx/R2IGeP6F+LpEkPE6Cwa99BjuFSRLQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.3olx5570k5.wasm"
    },
    {
      "hash": "sha256-TnrNFvaMsxoWY082BFmhGU9TJ8OMYFS2/hj1Qmv554M=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.e0gxfncngt.wasm"
    },
    {
      "hash": "sha256-YyRvPoAsHGloHtBxzdDtKQua5bzw6o/FV6DaxOOklMk=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.r2gku6q1e3.wasm"
    },
    {
      "hash": "sha256-RqtH7mdy4b/Lgn0w3gltdY5XDzcEOO9Dkfk2+/EMats=",
      "url": "_framework/Microsoft.Extensions.Configuration.FileExtensions.mth2ecl7oy.wasm"
    },
    {
      "hash": "sha256-h79dNVrO20e4FP23PnwScCNyP+Oh2A0RRoVYT9m3P+I=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.po4bsybtst.wasm"
    },
    {
      "hash": "sha256-o9ge8s6Z0HyXZRT4PCoWdI+ekqgqFzuEF5laExjMI+k=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.5azv7bznvz.wasm"
    },
    {
      "hash": "sha256-kqBQHr7y9jxYY+aVjD0W3XnkYyOh/5eFeZfT90r95HE=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.igwlhmsuet.wasm"
    },
    {
      "hash": "sha256-L3SybkUANkypkT0YAbmnulszWiYA0nknc/0Ndc++xUQ=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.peccai7y7w.wasm"
    },
    {
      "hash": "sha256-8hmK3dP5d19fusT1UcMF+/sUl7ih7OEgfpv65nmm4QY=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Physical.6zoatctfhk.wasm"
    },
    {
      "hash": "sha256-4gK2XiOZW1spwi6SjclUArobWe8zNVPWJ12SDMJpO/8=",
      "url": "_framework/Microsoft.Extensions.FileSystemGlobbing.i4488p3c9i.wasm"
    },
    {
      "hash": "sha256-aanrguDKs7KUDFk6x+hgM4EKNVkafnm4LzzRWLwzFQI=",
      "url": "_framework/Microsoft.Extensions.Logging.3xjj36rod4.wasm"
    },
    {
      "hash": "sha256-T99jysl/4nQz18nwDZBIhutCvUDXuHUIQzaHPAu09Gs=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.7i0fjb3g4i.wasm"
    },
    {
      "hash": "sha256-Yq9DpyYKCn3WmKOQvZrf/RztdQKI6nRnkIBQMhtSTUo=",
      "url": "_framework/Microsoft.Extensions.Options.ibshrnjvv0.wasm"
    },
    {
      "hash": "sha256-PypBe+6mw+fjYvnLwPqtaQ2QEnv1YxXLJZH2EmX8Tn4=",
      "url": "_framework/Microsoft.Extensions.Primitives.dh5wi8wu8k.wasm"
    },
    {
      "hash": "sha256-gK0qFVyjqnNYnFdIEIZ+KLcB3GJYrYXUAX8Jgu8d29Q=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.kbyrjhnquw.wasm"
    },
    {
      "hash": "sha256-aeokB1RJIhEr8tsAm3W03UEh0I21oO05uUy7fzznaww=",
      "url": "_framework/Microsoft.JSInterop.ltce2031wf.wasm"
    },
    {
      "hash": "sha256-tR+xyCj6TsJWF2a70b3D8HSh2ZbvG+4K/BaFMpXztcY=",
      "url": "_framework/Microsoft.VisualBasic.Core.pnarh8esv1.wasm"
    },
    {
      "hash": "sha256-Ppi7RX2Zc4WZ7QTn01FQrmZ8/7+janQ3i0hUj9B4OpA=",
      "url": "_framework/Microsoft.VisualBasic.ami2dw3700.wasm"
    },
    {
      "hash": "sha256-Pw02rU9JNCa4fqlgHO2kyvUR7egv79RTDUH/xt0GLkw=",
      "url": "_framework/Microsoft.Win32.Primitives.d5gcihifu3.wasm"
    },
    {
      "hash": "sha256-rREKgTALyHH2G21AD5RJylGDL8+FOmTdLYED+gX/wDY=",
      "url": "_framework/Microsoft.Win32.Registry.njtj2kcsgf.wasm"
    },
    {
      "hash": "sha256-3bmOcWiL/z+MQTq2Hb9R2i7kZX2owVXliIRy0MMRAxg=",
      "url": "_framework/System.7v46wull2w.wasm"
    },
    {
      "hash": "sha256-xxjvVrPGraEpX8tM5qZNRTgkoJd1g7Vu9ZOCZGnzErM=",
      "url": "_framework/System.AppContext.va0h1nqkkf.wasm"
    },
    {
      "hash": "sha256-V6CSDxoheVvou67v5m69PAs5iWL20JyTT/98U+Sup3k=",
      "url": "_framework/System.Buffers.59qvd7i4rj.wasm"
    },
    {
      "hash": "sha256-eaJZhGHIceldzkWRU1WwjAa5ItVa63gbVcHMySZAbUg=",
      "url": "_framework/System.Collections.Concurrent.dzcvvcutc3.wasm"
    },
    {
      "hash": "sha256-V9TxafzDwECx+gBv/k7iRVJmt+Q8/kB1GSW83nj469I=",
      "url": "_framework/System.Collections.Immutable.98c7qeyyhl.wasm"
    },
    {
      "hash": "sha256-i/SZL+s32JxdSHpNpNTkzmpnBFYzJXr2lqsZjfxUpUk=",
      "url": "_framework/System.Collections.NonGeneric.rck2dt6c5f.wasm"
    },
    {
      "hash": "sha256-IvxDnCUPjSrHXll2Vr63UmJC+zpTHcoXGoYS9K61gHM=",
      "url": "_framework/System.Collections.Specialized.6y5r9hykcl.wasm"
    },
    {
      "hash": "sha256-ukZqX1RRWFgFWIAXMRhNqxhzW2PYwjFZDv/P/mSLSt8=",
      "url": "_framework/System.Collections.qgei5ux3m3.wasm"
    },
    {
      "hash": "sha256-W99HrmbWMfr07DtIm/K6h8WEl58m8hjsbHre++T7ho8=",
      "url": "_framework/System.ComponentModel.Annotations.tuhlf5ri8p.wasm"
    },
    {
      "hash": "sha256-lj0A90U7u3tvvE/yfG15PcfiCNMt5a3uq+N2me+P/24=",
      "url": "_framework/System.ComponentModel.DataAnnotations.e2kkz2takt.wasm"
    },
    {
      "hash": "sha256-0zz/tb3x51pVXRUh/h/Ama58GnRQ02uU515Afyq8g4s=",
      "url": "_framework/System.ComponentModel.EventBasedAsync.73qje9ebzq.wasm"
    },
    {
      "hash": "sha256-j26sJxcoyb44hnkoVjOdF5Sa2Z97C6dzentgyapb9zo=",
      "url": "_framework/System.ComponentModel.Primitives.nmqbnfs5mx.wasm"
    },
    {
      "hash": "sha256-3M1W7wY9bnAAFttGzrfqBDzPt4Ewik/QtarIdVZ2ySs=",
      "url": "_framework/System.ComponentModel.TypeConverter.skv0e4pxeu.wasm"
    },
    {
      "hash": "sha256-fn/ITdotowOcWqJfcsWbe6txsUJjLiyk8OPNaFTc3cs=",
      "url": "_framework/System.ComponentModel.qiew3rsy2a.wasm"
    },
    {
      "hash": "sha256-KApi+olN+tOZKOvoE8WCcENfHIilRfypPFoYRv6hexY=",
      "url": "_framework/System.Configuration.8g1erzdz1d.wasm"
    },
    {
      "hash": "sha256-ix4n036O0RzRjxpagvCJdPfo19A4POD4NpXSzWuzUS0=",
      "url": "_framework/System.Console.hxcoe78zbc.wasm"
    },
    {
      "hash": "sha256-wse2JSTybT45ICd1VmD9Y42x9Y1+oeyYaQAFnXGoV4Q=",
      "url": "_framework/System.Core.qa01oqx5ul.wasm"
    },
    {
      "hash": "sha256-f3cWt1MrDdAbhpVHtI80RGIp6kZyrp5z/njlDiJsaew=",
      "url": "_framework/System.Data.Common.f0rf1453xw.wasm"
    },
    {
      "hash": "sha256-+P9qc9Wlp+5wVQ8hsTs5Wb9A881fTcHVj229AmbdhB4=",
      "url": "_framework/System.Data.DataSetExtensions.weqpybc6q6.wasm"
    },
    {
      "hash": "sha256-KANkO2Z0sjQLreFvnbNYWUnqDh2mgXkZLYb9BFgilNw=",
      "url": "_framework/System.Data.sbgyc07ebv.wasm"
    },
    {
      "hash": "sha256-DdKrhu2IDinWHl90zvSGGUVWz7BwhKflANQzC1t7pzE=",
      "url": "_framework/System.Diagnostics.Contracts.jcnrn2wb37.wasm"
    },
    {
      "hash": "sha256-hGz4sUIJV2zKyp59vnc9WTfc/Cbz2QnicT4/4jSNrbQ=",
      "url": "_framework/System.Diagnostics.Debug.gv1k5iasgt.wasm"
    },
    {
      "hash": "sha256-a48f2M5aCveX+I9R+Mrc1u5ngmOtVlCtrtFuUd67t2Y=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.x1xl21rhu3.wasm"
    },
    {
      "hash": "sha256-sWWI4DhibODLAUPPJnUKDmRp9kuu8d8x8cDQozccHGE=",
      "url": "_framework/System.Diagnostics.FileVersionInfo.3n10aa6qcl.wasm"
    },
    {
      "hash": "sha256-iw55wdcw1b6GxB3Rg+1sVejslbI9nLfzsxv8ET8aM04=",
      "url": "_framework/System.Diagnostics.Process.xdsv86jd4i.wasm"
    },
    {
      "hash": "sha256-3msh9DyttQxBo8BE6BrDEuBr/xqhnW9BRL1ZrsquhcI=",
      "url": "_framework/System.Diagnostics.StackTrace.2j7b9ys1ht.wasm"
    },
    {
      "hash": "sha256-2A/4+9e1bIKKrGZi81mXHmlVBHRuZt9U4oqPE2zRFk8=",
      "url": "_framework/System.Diagnostics.TextWriterTraceListener.kdghra6v1i.wasm"
    },
    {
      "hash": "sha256-YXTCvEbOC3EXSiKL1emqE/mAZPiKQaOmTV7Dr9rIPDM=",
      "url": "_framework/System.Diagnostics.Tools.pmbmoattrx.wasm"
    },
    {
      "hash": "sha256-qym+7hrAlKNIWc5syfnE56qMXmUEItcdfxRgy5Eyur4=",
      "url": "_framework/System.Diagnostics.TraceSource.b0yy1ii440.wasm"
    },
    {
      "hash": "sha256-ZorL5kPUKX5T/zYpoH0xD2E/eAjA7Pr5RSY5wEiXeaI=",
      "url": "_framework/System.Diagnostics.Tracing.qbgngehvau.wasm"
    },
    {
      "hash": "sha256-UZdX2fXh4cc2hWy8p97Q/NyOCMxRhHVZYF0hH5iR7P8=",
      "url": "_framework/System.Drawing.Primitives.tpnxln7pnf.wasm"
    },
    {
      "hash": "sha256-/I5mmbLDLKDRKEdptfi/MeMfwxcdyOstZtsQk35v58A=",
      "url": "_framework/System.Drawing.ciztwizd0i.wasm"
    },
    {
      "hash": "sha256-Mhvn0iBHiZjt9sqtKLVNTpSlGDWA7PE3mohtnPEwD3M=",
      "url": "_framework/System.Dynamic.Runtime.ivab5d2dv4.wasm"
    },
    {
      "hash": "sha256-YYPrGJE+ZOXKgdl90xwFEVMMoLtloE1iLwEHlFC86qI=",
      "url": "_framework/System.Formats.Asn1.rdntpa8fe2.wasm"
    },
    {
      "hash": "sha256-Uax4NDifOVSr59GHz6hEff/UAzZJWwje/HyJ/7DIXgU=",
      "url": "_framework/System.Formats.Tar.33485u3c26.wasm"
    },
    {
      "hash": "sha256-A9ekRpdhEZheSbWdx5pQZgpi6rCMEQamsshS6yBtiuc=",
      "url": "_framework/System.Globalization.3c5ch4zb2o.wasm"
    },
    {
      "hash": "sha256-2AnMPAtpaNSu1eUuKFSsXyKv7gbGQlgKFMRIixRWyZI=",
      "url": "_framework/System.Globalization.Calendars.sbg6ybzfap.wasm"
    },
    {
      "hash": "sha256-kRm0+yHpQSo5as5kJ+JjQ/280AnGpy2oU16aPCjr5sQ=",
      "url": "_framework/System.Globalization.Extensions.t5gns79vm1.wasm"
    },
    {
      "hash": "sha256-9ICA2fbX2U26rq8XKMvAT1PRKnVwV5MkN1qdtNmfktw=",
      "url": "_framework/System.IO.8pk18yhu4y.wasm"
    },
    {
      "hash": "sha256-2b32/ALIHabU75M7K35fJR5C4WZJSh00qY6E4+Y/0iA=",
      "url": "_framework/System.IO.Compression.Brotli.3dh5fzwie8.wasm"
    },
    {
      "hash": "sha256-oaFy5Woub9vO1xKEq7ly1Yicfb4UWfZDjuKFLN9Glxw=",
      "url": "_framework/System.IO.Compression.FileSystem.7uuh0ujx1r.wasm"
    },
    {
      "hash": "sha256-jpTh8C2feB9RNNWG+esXQ1didw67m3MNvSXZTwf/aY4=",
      "url": "_framework/System.IO.Compression.ZipFile.ifu223q7dt.wasm"
    },
    {
      "hash": "sha256-UUrENnnD+QNGypt8/hVAsG5VdDx+p1S3+SBqH5+sZvs=",
      "url": "_framework/System.IO.Compression.tls25eryqm.wasm"
    },
    {
      "hash": "sha256-v+G0AhvkLR1/YNlSWXwmnlIEJDTy6+0kFNvpkn0NEmU=",
      "url": "_framework/System.IO.FileSystem.AccessControl.v4tlf7rrjk.wasm"
    },
    {
      "hash": "sha256-7Qg+XOhMiwPEPzYlj8m5YOnBU2ZbWa1FeQ/MAiXk1q0=",
      "url": "_framework/System.IO.FileSystem.DriveInfo.34ocuhv94j.wasm"
    },
    {
      "hash": "sha256-hkdAo2UIS0srYY3Syjio8YrDhx7xwn9D95+MtJnmYOQ=",
      "url": "_framework/System.IO.FileSystem.Primitives.eapekjx0ao.wasm"
    },
    {
      "hash": "sha256-FkuHgk/MjpRNKeE4fimCt5+dGTExVRzAr2WTum52Zok=",
      "url": "_framework/System.IO.FileSystem.Watcher.mknf2tp35v.wasm"
    },
    {
      "hash": "sha256-GR1ZX10SS4FvRV8IsUrSth67GbNeZXU3CLbqpOrPr+0=",
      "url": "_framework/System.IO.FileSystem.pgk60cgbrf.wasm"
    },
    {
      "hash": "sha256-J8PLzhslS37t0u8+xSUmWF+VOxNxxng1+6Of5PxyZjo=",
      "url": "_framework/System.IO.IsolatedStorage.hygox872ac.wasm"
    },
    {
      "hash": "sha256-tjWaGVuuwVCwAIXD+UQCLgNFfcvjQdSSLj43ZCmw9aY=",
      "url": "_framework/System.IO.MemoryMappedFiles.ashpwxa3vk.wasm"
    },
    {
      "hash": "sha256-u6C+ZSrcoqfAgcwg9kYZQAjfGLD74dl2n894tNrgxtU=",
      "url": "_framework/System.IO.Pipelines.h5okosiym2.wasm"
    },
    {
      "hash": "sha256-cd6OPiWpt9CkkKH+8usn5qXT/sY3/nw+ugSYG+AUSRg=",
      "url": "_framework/System.IO.Pipes.AccessControl.3jekbwfpyb.wasm"
    },
    {
      "hash": "sha256-z1uHZROShs02a9qkZWZjpTLK7l5ThCj0Ve+sqiaPlco=",
      "url": "_framework/System.IO.Pipes.f0kmhzjsmn.wasm"
    },
    {
      "hash": "sha256-OZAaAPDxKadT+JRrWDgy5mxI2XpibqNtxYNdCt4Azxo=",
      "url": "_framework/System.IO.UnmanagedMemoryStream.98lrkav4gw.wasm"
    },
    {
      "hash": "sha256-DQ0YIId9H+kV2a++FjQIeaOVrnrc79aKNmjkN1BInhw=",
      "url": "_framework/System.Linq.Expressions.9psn0zr08p.wasm"
    },
    {
      "hash": "sha256-cbiPLYd9WWJD6fYczs/30zN6FBR92mXZfDy/EVUCuK8=",
      "url": "_framework/System.Linq.Parallel.lrh2ycespf.wasm"
    },
    {
      "hash": "sha256-6VzoamBzalJ91/AjSRENWzPlDZVvjE2l2186mGvng44=",
      "url": "_framework/System.Linq.Queryable.5lvgt76590.wasm"
    },
    {
      "hash": "sha256-h9xFKCThblW9VBB9YyuWzEytSm0xmzcOkKLX/ynCy4M=",
      "url": "_framework/System.Linq.tzvix0zrfc.wasm"
    },
    {
      "hash": "sha256-ahikZ6jpQouhVhpzpRG92L85AUk0E9/qvemknrZm+ZE=",
      "url": "_framework/System.Memory.mc9lxlhynd.wasm"
    },
    {
      "hash": "sha256-J0wnGa980JxP2wJseyVx1xGUSqY3kkjD+dTckm4IO7w=",
      "url": "_framework/System.Net.3lbaft3jbd.wasm"
    },
    {
      "hash": "sha256-bAFC54Doit1WAgjHp9e2p5JLR5iqIcZsmR0M83xe8MU=",
      "url": "_framework/System.Net.Http.Json.k2t9eiz2ps.wasm"
    },
    {
      "hash": "sha256-d0cPVA3JwkyXu00/fy4i82WO2a4p2hHhe4+hRUzcnbU=",
      "url": "_framework/System.Net.Http.dbj3sqfsj2.wasm"
    },
    {
      "hash": "sha256-8lLFzDoRNScV8Jd7pruOnUm9aBLGXuVPlkkUuHO9qFE=",
      "url": "_framework/System.Net.HttpListener.y8b80mdihw.wasm"
    },
    {
      "hash": "sha256-bnyttB1nzX3cP8lmAhBxF/FRqq32tLof3v+Qw6MtJ/0=",
      "url": "_framework/System.Net.Mail.yskh0ggf9n.wasm"
    },
    {
      "hash": "sha256-E9nDeY5Idj9/uZFINXZo72HOmLmrbUm1EUA6Mw/NxTQ=",
      "url": "_framework/System.Net.NameResolution.fps7k2zdg8.wasm"
    },
    {
      "hash": "sha256-8zB7tFr8nA7zIvAkzBVxB9Xn81eXCi/OS6+w1yo8rFE=",
      "url": "_framework/System.Net.NetworkInformation.5e5zt3e762.wasm"
    },
    {
      "hash": "sha256-zTDTr/2e9Wi6eZClIebaQ+al63T6CtV0Gmb420UwZnY=",
      "url": "_framework/System.Net.Ping.rui35iunfo.wasm"
    },
    {
      "hash": "sha256-QJUuefk6ATSKU0pYKy4hc/IyCElXJZL7nOKdNfWbl0c=",
      "url": "_framework/System.Net.Primitives.k3wdvqqvj1.wasm"
    },
    {
      "hash": "sha256-zoLN78UQi4LLuvxaBX+wok2C6cu8+NJSsvAkYDZmnM0=",
      "url": "_framework/System.Net.Quic.u9lqbdx92u.wasm"
    },
    {
      "hash": "sha256-0EhZ+aqTjPXWoI+6hbEk/ZU4xDFiDR16Rp4BuE+WB14=",
      "url": "_framework/System.Net.Requests.c14f1tsc5y.wasm"
    },
    {
      "hash": "sha256-iyZRNGDfI7Lv5cxBMQZ55luAdLnlopSv7kVdLEQ0eQ0=",
      "url": "_framework/System.Net.Security.9vtd9ixjnq.wasm"
    },
    {
      "hash": "sha256-9KP52Vt+AVJOXBAbsRszItBZA7n70biaHpHpQruYkZk=",
      "url": "_framework/System.Net.ServicePoint.0dqiqdmp0m.wasm"
    },
    {
      "hash": "sha256-MuQtQig+qIZkw88i9o29zNlsiJ36LS3VBb9TNWhpUFw=",
      "url": "_framework/System.Net.Sockets.2wrwn6si7v.wasm"
    },
    {
      "hash": "sha256-6oB1JcAekdE24/oDPBHvTs6aAPv7m/d8PBHR0rbdDRs=",
      "url": "_framework/System.Net.WebClient.6p2l439iwa.wasm"
    },
    {
      "hash": "sha256-DSwo/56j/PX33TPMoMtZYSDtMgpA4rctMEEdooMjvMs=",
      "url": "_framework/System.Net.WebHeaderCollection.fdttubzemg.wasm"
    },
    {
      "hash": "sha256-XSM5dO2V1XeeOdkXV96I5xmyy1FDxFPkWe2AXuyH2e0=",
      "url": "_framework/System.Net.WebProxy.3k5mjtxief.wasm"
    },
    {
      "hash": "sha256-k65gE5OKQmKSYRD2tJ65udfGaP5sLpB/lpl/B+d1X8c=",
      "url": "_framework/System.Net.WebSockets.56xixqj5ya.wasm"
    },
    {
      "hash": "sha256-5zkZZEgMXeY2yD1XSqcLItnxwQj24CQVlwBBo4pjveo=",
      "url": "_framework/System.Net.WebSockets.Client.v245u6u096.wasm"
    },
    {
      "hash": "sha256-KdA/na0SNbx/Vu/sNCGmdtEqAWN5uE92jS1w62yDyXA=",
      "url": "_framework/System.Numerics.5pejfcap7s.wasm"
    },
    {
      "hash": "sha256-3oRhzCUS3o1DBADx0V1iHUlN1TTEergo9MbaqexFhHY=",
      "url": "_framework/System.Numerics.Vectors.ug8s75x704.wasm"
    },
    {
      "hash": "sha256-e50s1r22ufRrpd68DuKJMiB5wgtc/dqvjzXVYxuIfnY=",
      "url": "_framework/System.ObjectModel.b8930rs9pv.wasm"
    },
    {
      "hash": "sha256-eqNAQo0EEdfSPudJmtF5+LF+GpanKFu2gaylvwfOXcs=",
      "url": "_framework/System.Private.CoreLib.m8l0lrv2y9.wasm"
    },
    {
      "hash": "sha256-w/MHE4c4fpt0Pr/jhXRZOmHKGmh3FN668O51X1niLZI=",
      "url": "_framework/System.Private.DataContractSerialization.zo0djva9vq.wasm"
    },
    {
      "hash": "sha256-R57Gz4Q87ucfOqG6A5M2j7SLc6QQYWDcBh9b9DIza6E=",
      "url": "_framework/System.Private.Uri.fqtz17oqh3.wasm"
    },
    {
      "hash": "sha256-+hEG4SFgBeyDWR51hoGZP8u7EKZmzQyjo4AyJN1mp04=",
      "url": "_framework/System.Private.Xml.Linq.mgnxdzm0t2.wasm"
    },
    {
      "hash": "sha256-S2GMdFSHHHuwFXaAevVX96YfAEiNNWFyI8JJl+V+u3A=",
      "url": "_framework/System.Private.Xml.hpi4vu3uqt.wasm"
    },
    {
      "hash": "sha256-fb6bYHke7PIa1ShK8SihyylYAjlP1TZtNM5QRJyTEig=",
      "url": "_framework/System.Reflection.DispatchProxy.xrhmnp0h2s.wasm"
    },
    {
      "hash": "sha256-EKJvB0CrHP1+nkKqMrUO/PLFfeEsQHLH3D+1R6R+ykE=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.8icjscdbkk.wasm"
    },
    {
      "hash": "sha256-ZO6KEmORPGRGIagzArgyOzvoVG5gFiLBQ8rKrX9OXpc=",
      "url": "_framework/System.Reflection.Emit.Lightweight.wlxdzg4qns.wasm"
    },
    {
      "hash": "sha256-xVsyp/+10zvnWSJusqaztVTmSRmIOsHOaQaVTbuHwmQ=",
      "url": "_framework/System.Reflection.Emit.zqnkzbijzm.wasm"
    },
    {
      "hash": "sha256-l4cOOKdE45Ek4TxcdrGUzXT3C0/zYpngVmLFWTUyfgE=",
      "url": "_framework/System.Reflection.Extensions.fmnchl60k9.wasm"
    },
    {
      "hash": "sha256-zlYzuMzR89I9wdyKqaV8Lc3nljv4FXY2TXauUbTc7Gk=",
      "url": "_framework/System.Reflection.Metadata.2rc14jro5c.wasm"
    },
    {
      "hash": "sha256-LMNNpLuFjkcPpH7TW0BiX24cgr5rXrgvO1eamoPFlNU=",
      "url": "_framework/System.Reflection.Primitives.kihe73ysh4.wasm"
    },
    {
      "hash": "sha256-Stbhy6xV1dy5f7IyFXUwt/x7hg1F3LZva8v0pT2tyBw=",
      "url": "_framework/System.Reflection.TypeExtensions.uy1fmvky0d.wasm"
    },
    {
      "hash": "sha256-40NKSfmAxujLIs5JVIrP1tDTmg6Od+NyTLhGUYsfnvI=",
      "url": "_framework/System.Reflection.t827tyzqiz.wasm"
    },
    {
      "hash": "sha256-aVGsS/JXzhfwN9TfCBAtw1g7NMRPL9LaTZCtFztSbhg=",
      "url": "_framework/System.Resources.Reader.3dcg03q2w1.wasm"
    },
    {
      "hash": "sha256-ekBkbPY9YCKB/S9SUcGSjxIfT94HI8nSZDLrsJpU/sg=",
      "url": "_framework/System.Resources.ResourceManager.m427hy8jmz.wasm"
    },
    {
      "hash": "sha256-IQJ5h/9BFS3QXHGhzyEbIWSnk8Lpj09ZZpsfsm3QDyE=",
      "url": "_framework/System.Resources.Writer.v0s4jp6ll6.wasm"
    },
    {
      "hash": "sha256-xB6WdyKUMhkoOwawnMzgQWBo/O/Sax9ulttp1SpFvzU=",
      "url": "_framework/System.Runtime.CompilerServices.Unsafe.09ooinsr07.wasm"
    },
    {
      "hash": "sha256-XWl+Zdm4wzPXT1SkvEvKES5f7zdJ+DeVC5T03ToO5VQ=",
      "url": "_framework/System.Runtime.CompilerServices.VisualC.73vtk0sktr.wasm"
    },
    {
      "hash": "sha256-y1T8Q3REKRk58fVG58gJSY5U7FQjZTN6sfNnorIfMqU=",
      "url": "_framework/System.Runtime.Extensions.7ll6mvv8p3.wasm"
    },
    {
      "hash": "sha256-XQgS8edpLm8KF13kXX6zPy2wBgTNbs9mesG89VSe4bw=",
      "url": "_framework/System.Runtime.Handles.t8uh9f5va4.wasm"
    },
    {
      "hash": "sha256-K/ORcazfO7Xs8fU1/txrbqirn3jlRAHwbcOWXljiWQI=",
      "url": "_framework/System.Runtime.InteropServices.5wloosw2px.wasm"
    },
    {
      "hash": "sha256-l+9KhYwpqeHVBQpQuhKUnP6fuBzmaYXfoH/dfuXkVC8=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.t3yr32kz3b.wasm"
    },
    {
      "hash": "sha256-m0IDwpxEl9tacfpooIhz5owlc/Jmu2AKLZtpvx5N5uM=",
      "url": "_framework/System.Runtime.InteropServices.RuntimeInformation.7dku0knt1w.wasm"
    },
    {
      "hash": "sha256-V9ZAfO5pOPlXcveMn90+ihSjxiP6LYqGRLyXiuxstfo=",
      "url": "_framework/System.Runtime.Intrinsics.35iqgu79bo.wasm"
    },
    {
      "hash": "sha256-JZpxA907xBJKgyHMmLvujlsme+paLoPci2CxRPBjqK0=",
      "url": "_framework/System.Runtime.Loader.tisnqghg4p.wasm"
    },
    {
      "hash": "sha256-THs+kzK74NxJeKA7BebdtRqdd23fZE0lMCC3aXCO3PI=",
      "url": "_framework/System.Runtime.Numerics.g7sehl9dom.wasm"
    },
    {
      "hash": "sha256-5BEMcWjEJ5F8QVU2hraq3Yv3TJCZ112Esu6fBxRT9qA=",
      "url": "_framework/System.Runtime.Serialization.Formatters.ojywjmtre4.wasm"
    },
    {
      "hash": "sha256-F8V+i4opmOBf18ugICN5ituzTYl3j9vZ/NdjfBLPBmg=",
      "url": "_framework/System.Runtime.Serialization.Json.jl5jywcm7g.wasm"
    },
    {
      "hash": "sha256-l9gegmpD9xgq4//C6V51Vc1eS7uofxN6fY+Q60Wi/is=",
      "url": "_framework/System.Runtime.Serialization.Primitives.n0cr308ooe.wasm"
    },
    {
      "hash": "sha256-G3kRJs9VB0Vh4xdsXQzNCOebymeTDkezcaC7I5E4FyI=",
      "url": "_framework/System.Runtime.Serialization.Xml.b449gbme59.wasm"
    },
    {
      "hash": "sha256-R2boVafEe4gwWGVFqFXkgQFvHPmtIeomNPF/35saQf8=",
      "url": "_framework/System.Runtime.Serialization.bjtji6i4hl.wasm"
    },
    {
      "hash": "sha256-MFGYZrUPSfLQtTlvNo38eiO9SZbMFCfIyrGh/Pt0WGI=",
      "url": "_framework/System.Runtime.o6u8cmopyl.wasm"
    },
    {
      "hash": "sha256-ejzcoq3SBNSABfbcushbb4PHCH9BfeiP8/10JZ0uibA=",
      "url": "_framework/System.Security.AccessControl.uyqo1903ma.wasm"
    },
    {
      "hash": "sha256-FWDgceof4Ee3bEdoDgW/ELhiE8L4XXmZxyPPWujdZE4=",
      "url": "_framework/System.Security.Claims.v717uggyuv.wasm"
    },
    {
      "hash": "sha256-HwWJGmi8TQAOUEVE+USYvIov4log88UkG1ssiFje6gU=",
      "url": "_framework/System.Security.Cryptography.Algorithms.rl9yoaehuf.wasm"
    },
    {
      "hash": "sha256-HdG8jgZrHHrnLXDaK/nHWYP8wgOSeKBizDZezYD3fPs=",
      "url": "_framework/System.Security.Cryptography.Cng.jsifux6jz3.wasm"
    },
    {
      "hash": "sha256-zDt/ELzKmpe6TTcz9yqI1wJ000jMQmNqna5aSlFCUV0=",
      "url": "_framework/System.Security.Cryptography.Csp.sm4juauoad.wasm"
    },
    {
      "hash": "sha256-7x3c3ExcpjdwZ7eg0stj17lM0euz8mXhov7T3eajLgw=",
      "url": "_framework/System.Security.Cryptography.Encoding.3vpgvucj7f.wasm"
    },
    {
      "hash": "sha256-kIJ42NTVHTt96Jn3GYRECyppOMgF4x0ZsapEzAESOio=",
      "url": "_framework/System.Security.Cryptography.OpenSsl.o62275bb8t.wasm"
    },
    {
      "hash": "sha256-EIVecaIEvrnpLN+GQXkHy1wmdoIsBYO2MGGmIE6FFKw=",
      "url": "_framework/System.Security.Cryptography.Primitives.82qwfoix19.wasm"
    },
    {
      "hash": "sha256-6SMG84hGTKaERAPGkSqxYdsAXHjxRWZTJcEgozNmhB4=",
      "url": "_framework/System.Security.Cryptography.X509Certificates.bfnu6xuxtt.wasm"
    },
    {
      "hash": "sha256-ijTfKx7SEmWd53oT7q7sYxqwKYJoySUYamXlQ4z25JU=",
      "url": "_framework/System.Security.Cryptography.yxbgbwo9dk.wasm"
    },
    {
      "hash": "sha256-Q7mye96xvf/Tidx0HI5bAWw2k9/0cbvhJAHwuqA31js=",
      "url": "_framework/System.Security.Principal.5qx0468v09.wasm"
    },
    {
      "hash": "sha256-Rx2054c/cnu6rq/U7XYISwSUh2c53pHu574bK1dQzbQ=",
      "url": "_framework/System.Security.Principal.Windows.xih4h0wwvb.wasm"
    },
    {
      "hash": "sha256-sxb/0l9zcM7INwqRaML4hc+8DFGeuCc+dbHUeFjE44o=",
      "url": "_framework/System.Security.SecureString.528mvm06b7.wasm"
    },
    {
      "hash": "sha256-fcRmNZbhbjIkP7CKKM0CvX6YyrDpoluFIMBPCzT3bSU=",
      "url": "_framework/System.Security.l65lbn1gqz.wasm"
    },
    {
      "hash": "sha256-NyuHz5moXAecf3Z79fQYCpHHbpMXumfu0TvlBR8ELYE=",
      "url": "_framework/System.ServiceModel.Web.5xauay7zhv.wasm"
    },
    {
      "hash": "sha256-wE0FPhJz/Oj1M+iXtO61caUpZKSKdptUvaPGBVSEIe4=",
      "url": "_framework/System.ServiceProcess.oyeiuus3tg.wasm"
    },
    {
      "hash": "sha256-k/bhkunCr9ZE0RtwN6UiWtomULHLf6cavld6JRPPRXY=",
      "url": "_framework/System.Text.Encoding.CodePages.7zia06akrn.wasm"
    },
    {
      "hash": "sha256-ZuHJskeIxNEF/zT49sHP89ON3NtuaABp2zWGUVc+yDQ=",
      "url": "_framework/System.Text.Encoding.Extensions.uupasd1pz5.wasm"
    },
    {
      "hash": "sha256-KmklfuSdYscQPCkPNRtB7kTHPE6X5d34obxxvjm0hsY=",
      "url": "_framework/System.Text.Encoding.ujytdimout.wasm"
    },
    {
      "hash": "sha256-9S3UsXD5TSQZ/zPUeN1rGZ7VOlHWkE5ubcRVNmAm87g=",
      "url": "_framework/System.Text.Encodings.Web.t2p89d4v39.wasm"
    },
    {
      "hash": "sha256-kJSspFnB3M+RzGgcNtr7KhV870lTPmh0y6fJ83YQczY=",
      "url": "_framework/System.Text.Json.47rbhjjg7l.wasm"
    },
    {
      "hash": "sha256-zIwZ71w8yXeTaZOosfOYw8XWv6QShO6+jvZQKOHI0os=",
      "url": "_framework/System.Text.RegularExpressions.sazigcv1yn.wasm"
    },
    {
      "hash": "sha256-hqx411QH03kg+mktttydn6YMRHNSTAVh4aH+F10Jk24=",
      "url": "_framework/System.Threading.Channels.m4qxakxq8g.wasm"
    },
    {
      "hash": "sha256-dfrQJfYJWAt4pOn/xEHBFG6AIAcJ/IBzfqqA2USDY9g=",
      "url": "_framework/System.Threading.Overlapped.lo4z80rp0c.wasm"
    },
    {
      "hash": "sha256-6lePvQenehlVCZbtHozVW0Vd8xFm1J+YD1pq2fGX2co=",
      "url": "_framework/System.Threading.Tasks.Dataflow.61swqm982a.wasm"
    },
    {
      "hash": "sha256-ewuG2Zh1nyczYCz7EjpSwv1XppsDvxYcWFbW1Ab4NA0=",
      "url": "_framework/System.Threading.Tasks.Extensions.jakvnz3m7s.wasm"
    },
    {
      "hash": "sha256-wcnuaft0Bq7KIpREuCG4/pZlyNRRvE/3ytWAG0Ntd+Q=",
      "url": "_framework/System.Threading.Tasks.Parallel.fw36tsnp99.wasm"
    },
    {
      "hash": "sha256-8RJyqJDWCJsbs6McfKtN5VitOv7zTA4KXLPu4tLuL4Q=",
      "url": "_framework/System.Threading.Tasks.l72vm41uz0.wasm"
    },
    {
      "hash": "sha256-YLIZEbDdwGo80k6iF2SYUK13g8lcMjMMF05DPVbAJAY=",
      "url": "_framework/System.Threading.Thread.cppdfcd43c.wasm"
    },
    {
      "hash": "sha256-86tzWlnN8cxfTU+FHxVYyvNS63vC3tZpitJBwRD9Dxc=",
      "url": "_framework/System.Threading.ThreadPool.7r2gqczoh6.wasm"
    },
    {
      "hash": "sha256-WEf1awknmeLccoUMeiKDihcSWd9XnoUc3uQnfuklzqA=",
      "url": "_framework/System.Threading.Timer.49m4b59vr3.wasm"
    },
    {
      "hash": "sha256-ZfPK2MPCwFmDUp2kirBogKKNGV8uH/mwdyejobwhTjQ=",
      "url": "_framework/System.Threading.vjxnb64o4t.wasm"
    },
    {
      "hash": "sha256-BPCMrbDC+s/UOeGIyhok2ne2XDHhXE/QVtBhm4LTaeE=",
      "url": "_framework/System.Transactions.Local.skl3sp6q46.wasm"
    },
    {
      "hash": "sha256-STmLpRi408XCBjXxvJFgbz0UxEq/1gEkeABCQhXLc48=",
      "url": "_framework/System.Transactions.nc33jw2gx9.wasm"
    },
    {
      "hash": "sha256-W9hqPSqEhskSdjkdpsOOHJoWLWe/RXD0giByAz36K/s=",
      "url": "_framework/System.ValueTuple.zadg1k46fs.wasm"
    },
    {
      "hash": "sha256-eS9euC6+bzjoXcIfqGbEm+IVzB1plhaghXiuYSzA6Kk=",
      "url": "_framework/System.Web.3x6i9htmj2.wasm"
    },
    {
      "hash": "sha256-Z7bDZh7J3Y/el4o+T7thZV93I61ZVWUmL5bp94pJW9k=",
      "url": "_framework/System.Web.HttpUtility.lt7cz5annu.wasm"
    },
    {
      "hash": "sha256-gd7c2e8dftH8kY3Abyd9gN9Nr+zXEnP5vuu7Nvk/1lY=",
      "url": "_framework/System.Windows.bt6gbcg8fr.wasm"
    },
    {
      "hash": "sha256-XeybUtjX5KSERWnRhDExA9W+a6g8oSOIb9pe5SXo1ZU=",
      "url": "_framework/System.Xml.Linq.j40kmg850i.wasm"
    },
    {
      "hash": "sha256-/31ntBwNgnWtVais15jOT8xdcC1m5PE7Jl7YLP/4ZNo=",
      "url": "_framework/System.Xml.ReaderWriter.5jxd7ck9if.wasm"
    },
    {
      "hash": "sha256-2+saKT0pkPMaqx4EISF2H5s/2J3QU6pXPKKbiYRAqY0=",
      "url": "_framework/System.Xml.Serialization.717pwf0ppe.wasm"
    },
    {
      "hash": "sha256-3XDGOVSibPZ9pMaEoASmThXKaGwV9pw259RO6phzve4=",
      "url": "_framework/System.Xml.XDocument.5uiuylyrld.wasm"
    },
    {
      "hash": "sha256-zEPfvUjEQMNN3Vkz0pko70qfQHYMfMh5uN7mxcMkLqw=",
      "url": "_framework/System.Xml.XPath.XDocument.0b01s4uyq5.wasm"
    },
    {
      "hash": "sha256-oxofOMgxVk19yQlC2s1Cco7SCQ15oE+aOhi8+boiFDc=",
      "url": "_framework/System.Xml.XPath.rikbuwsnkw.wasm"
    },
    {
      "hash": "sha256-w7d2M9aBYTRgZihw9mzYwMzNOycZluG+DNRoGUk/Eag=",
      "url": "_framework/System.Xml.XmlDocument.vd9l1h9eer.wasm"
    },
    {
      "hash": "sha256-rnJJ3iDZ/ecLFED6U7AoaSMR4+tvg5t5uTeaGdkA/tI=",
      "url": "_framework/System.Xml.XmlSerializer.yjivvx2t6i.wasm"
    },
    {
      "hash": "sha256-Kir3TMzm9AsV9jR8Y/eh9mLG3EttRq1g5mdJRqEf0GI=",
      "url": "_framework/System.Xml.yic7rd6pxt.wasm"
    },
    {
      "hash": "sha256-gyJyeSLAns1YIwrPLmw2VAbNeQgpzgW5xIJovvySzEc=",
      "url": "_framework/WindowsBase.300iq62cmr.wasm"
    },
    {
      "hash": "sha256-jHh2dmXHQOLUrJH6tpJY86y4M9Vo0G+TCbnqmsJ6+xk=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-QNRSRjyyEpdXccKpfABFMGGtZpoZx+mjQzWQgqImS8E=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-+WNo1F87KKTUGf12QwMcsKDZMFckNG72OFoCYcgqRjA=",
      "url": "_framework/dotnet.js.map"
    },
    {
      "hash": "sha256-OfGprhDb4vgzxzOBj9RRMcRnAdSZR0hH5g5LHA0MzIE=",
      "url": "_framework/dotnet.native.xidrk0eo52.js"
    },
    {
      "hash": "sha256-epub+cT7AAhrDiekrY5B4YmQztQS22XhiPGS89zUOsY=",
      "url": "_framework/dotnet.native.y68cfu4kuf.wasm"
    },
    {
      "hash": "sha256-3egSZfVHFUpXw3QwgiaxDQns5wWmrugiXEFPbJyCk2g=",
      "url": "_framework/dotnet.runtime.hv7sykez1z.js"
    },
    {
      "hash": "sha256-Gok9AFSdJFzZyb+VaYsrPSyeDoer4a0us2D8YlTqatY=",
      "url": "_framework/dotnet.runtime.js.map"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-XShGzkyhqE1Qwz15C0W5EDSl0wiqbw4NUP1UtzupbE4=",
      "url": "_framework/mscorlib.560m239brp.wasm"
    },
    {
      "hash": "sha256-PjcsgKDGCmf1+ahJpjBZtaqHugXi6ZJaAVAkX0OzhaI=",
      "url": "_framework/netstandard.yg21u65s4h.wasm"
    },
    {
      "hash": "sha256-MrI+3lUFlnP1xW5bvjZLzPQbhrnWYqEV49QR8KyPNBQ=",
      "url": "_framework/segmentation-rules.json"
    },
    {
      "hash": "sha256-vGbjgqEqv4y3q5OB8W2R9LthkuF8mQfHFeNdKSReSmU=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-sY0Qcqp50BoFWHOwEBRVwAyh/P9zR0X4ccKlm7Tmy+Q=",
      "url": "images/dell.webp"
    },
    {
      "hash": "sha256-JyfypNwNzBf1riTqgVXfu3kAme11oE3biDvJWMAVwEw=",
      "url": "images/iphone.jpg"
    },
    {
      "hash": "sha256-vw4qjhxIIhDufY7tFKXWz2lwvEAzSXZPXVJ/yv377v4=",
      "url": "index.html"
    },
    {
      "hash": "sha256-Yy5/hBqRmmU2MJ1TKwP2aXoTO6+OjzrLmJIsC2Wy4H8=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-5nDHMGiyfZHl3UXePuhLDQR9ncPfBR1HJeZLXyJNV24=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-CZxoF8zjaLlyVkcvVCDlc8CeQR1w1RMrvgYx30cs8kM=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-vMxTcvkC4Ly7LiAT3G8yEy9EpTr7Fge4SczWp07/p3k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-lo9YI82OF03vojdu+XOR3+DRrLIpMhpzZNmHbM5CDMA=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-l8vt5oozv958eMd9TFsPAWgl9JJK9YKfbVSs8mchQ84=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-V8psnHoJS/MPlCXWwc/J3tGtp9c3gGFRmqsIQgpn+Gg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-/8jh8hcEMFKyS6goWqnNu7t3EzZPCGdQZgO6sCkI8tI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-2BubgNUPlQSF/0wLFcRXQ/Yjzk9vsUbDAeK2QM+h+yo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-KyE9xbKO9CuYx0HXpIKgsWIvXkAfITtiQ172j26wmRs=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-H6wkBbSwjua2veJoThJo4uy161jp+DOiZTloUlcZ6qQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-GAUum6FjwQ8HrXGaoFRnHTqQQLpljXGavT7mBX8E9qU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-GKEF18s44B5e0MolXAkpkqLiEbOVlKf6VyYr/G/E6pw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-j5E4XIj1p1kNnDi0x1teX9RXoh1/FNlPvCML9YmRh2Q=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-h5lE7Nm8SkeIpBHHYxN99spP3VuGFKl5NZgsocil7zk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-BnC+WHD8dov6lySmPw0oZRVUS1Bu/GfvF82iqXMsAEU=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-9GCjuHVgWmztIgLtXOGdixJfgxk4FG9gOiD2InHIA4o=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-CDOy6cOibCWEdsRiZuaHf8dSGGJRYuBGC+mjoJimHGw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-PhtzaTAJBHGemDKmirbuAcj6IeF5WRLdER9hbmx5bfg=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-idtgIAYz2ciWaDrW3/eaOIROimwN+tKGplS2ywZmQv0=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-M+a16hH53OBNSXGtY9ehNiB9nAkFLVfXmonXomjZ5bM=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-QZdFT1ZNdly4rmgUBtXmXFS9BU1FTa+sPe6h794sFRQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-8f03po0krljA3TGxgRJCW7SKhRUSTZR0WlPuR0p3JZs=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-rHKWZnCE7CxdQ8ySmoA0ZHDY9bSSrAYWLxRe8UPZdjY=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-yGFdjC0Qqdvo0PK9uUXKGj4gwuSoDG6FYlmEXWBcWxc=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-3gQJhtmj7YnV1fmtbVcnAV6eI4ws0Tr48bVZCThtCGQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-yAGdvr0tyQFzSsmGY3aCOA3oiWd63z6lIWS3KoPFEjA=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-5mSSqsKHTtbdzux679G6PTIWm9utzJWmbD385NauBJs=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-enKgCMkYmCpfEcmg6Annbmc40VZ/A6aYYSQjZfVn2cU=",
      "url": "sample-data/weather.json"
    }
  ]
};
